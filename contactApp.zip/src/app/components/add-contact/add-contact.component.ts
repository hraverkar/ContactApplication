import { ContactService } from './../../services/contact.service';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.scss'],
})
export class AddContactComponent implements OnInit {
  public errorMsg: string;
  @ViewChild('image') image: ElementRef;
  constructor(private contactService: ContactService) {}

  ngOnInit(): void {}

  addNewBlog(form: NgForm) {
    // tslint:disable-next-line: one-variable-per-declaration
    const articleCategory = form.value.articleCategory,
      articleTitle = form.value.title,
      author_name = form.value.author_name,
      date = form.value.date,
      description = form.value.description,
      tags = form.value.tags,
      img = (this.image.nativeElement as HTMLInputElement).files[0];

    // this.contactService
    //   .addBlogDetails(
    //     articleCategory,
    //     articleTitle,
    //     author_name,
    //     date,
    //     description,
    //     tags,
    //     img
    //   )
      // .then((msg) => {
      //   console.log(msg);
      //   form.reset();
      // })
      // .catch((err) => {
      //   console.log(err);
      // });
  }
}
