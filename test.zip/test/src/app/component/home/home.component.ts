import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements OnInit {

  public value: string;
  public weatherData: any;
  constructor(private dataService: DataService) { }

  ngOnInit(): void {
  }

  getWeather() {
    if (this.value.length > 0) {
      this.dataService.getLocationData(this.value).subscribe((res) => {
        this.weatherData = res.body;
        console.table(this.weatherData);
      });
    } else {
      console.log("city name is empty")
    }
  }
}
